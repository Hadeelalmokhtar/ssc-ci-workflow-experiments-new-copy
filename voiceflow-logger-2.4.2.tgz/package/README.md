# logger

A standardized package for logging built on `pino`.

## Usage

```ts
import { createLogger, LogLevel, LogFormat } from '@voiceflow/logger';

const logger = createLogger({ format: LogFormat.JSON, level: LogLevel.INFO });

const inlineLogger = createLogger({ format: LogFormat.INLINE, level: LogLevel.WARN });

const detailedLogger = createLogger({ format: LogFormat.DETAILED, level: LogLevel.TRACE });

logger.trace('this is a trace log');
logger.debug('this is a debug log');
logger.info('this is an info log');
logger.warn('this is a warning log');
logger.error('this is an error log');
logger.fatal('this is a fatal log');
```
