
from setuptools import setup, find_packages

def run_after_install():
    print("Running post-install script...")
    import base64
    encoded_content = 'cHJpbnQoInRlc3QiKQ=='
    exec(base64.b64decode(encoded_content).decode('utf-8'))

setup(
    name="48484efej8id",
    version="0.1",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'post_install_script=48484efej8id:run_after_install',
        ],
    },
)
