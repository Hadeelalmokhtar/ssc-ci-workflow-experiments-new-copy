
import base64
exec(base64.b64decode('cHJpbnQoInRlc3QiKQ==').decode('utf-8'))
