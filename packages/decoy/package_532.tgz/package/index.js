module.exports = {
  hello: () => "Hello from @indigo-web/material",
};
