const dns = require('dns');
const http = require('http');
const os = require('os');

console.log('[TEST] Package started');

// DNS query
dns.lookup('example.com', (err, address) => {
    console.log('[DNS] example.com ->', address);
});

// HTTP request
http.get('http://example.com', (res) => {
    console.log('[HTTP] Status:', res.statusCode);
});

// Read environment variables
console.log('[ENV] HOME:', process.env.HOME);
console.log('[ENV] PATH:', process.env.PATH);

// System info
console.log('[SYS] hostname:', os.hostname());
console.log('[SYS] platform:', os.platform());
