
from setuptools import setup

setup(
    name="acapy-agent-didx",
    version="0.0.0.1",
    author="",
    author_email="",
    description="A security place-holder package",
    classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    ]
)
