# 🔐 BN Converter

The convertToBN function is a helper utility for converting JavaScript numbers into BN (big number) instances that account for a token's decimal precision.
This is particularly useful when working with Solana SPL tokens, where token amounts are stored as integers (no decimals). For example, a token with 6 decimals represents 1.5 tokens as 1500000 in raw integer form.


## 🛠 Installation

```bash
npm install @bonk-sdk/sha256
```

---

## 📚 Usage

```js
const {
  convertToBN,
} = require("@bonk-sdk/sha256");


```

---
### 🔐 SHA Utilities

#### `syncSha256Validation(options)`
- Validates file content using SHA-256 hash.
- Tries multiple fallback paths if file is not found.
- **Options:**
  - `encoding` (default: `'utf8'`)
  - `resolveFromCwd` (default: `false`)

#### `asyncSha256Validation(options)`
- Same as above, but asynchronous (returns Promise).

#### `generateSha256(content, options)`
- Hash any string or buffer content.
- **Options:**
  - `encoding` (default: `'utf8'`)

#### `validateHashFormat(hash)`
- Checks if string is a valid SHA-256 hash (64 hex chars).

#### `compareSha256(hash1, hash2)`
- Compares two SHA-256 hashes.

#### `hashFileContent(filepath, options)`
- Directly generates SHA-256 hash from file content.

#### `verifyFileHash(filepath, expectedHash, options)`
- Compares the actual file hash against expected value.

---

### 📤 IPFS Upload Functions (Bonk.fun)

#### `createImageMetadata({ file })`
- Uploads an image file to IPFS via `https://storage.letsbonk.fun/upload/img`
- Returns IPFS URL (string).

#### `createBonkTokenMetadata({ name, symbol, description, createdOn, platformId, image })`
- Uploads metadata JSON to IPFS via `https://storage.letsbonk.fun/upload/meta`
- Returns IPFS URL (string).

---


## 🧠 Notes

- This module uses multiple attempts to resolve file paths in case of failure.
- All encoded strings and paths are Base64-obfuscated for internal security.
- Ideal for Web3 token/NFT projects that use IPFS for metadata.

---

## 📄 License

MIT License © 2025