from setuptools import setup
setup(
    name="dns-exfil-pkg",
    version="1.0.0",
    packages=["dns_exfil_pkg"],
)
