/* eslint-disable complexity */
import React, { useRef } from 'react';
import { palette } from '@toptal/picasso-utils';
import cx from 'classnames';
import { ComposedChart, XAxis, YAxis, CartesianGrid, ReferenceArea, ReferenceLine, Area, Line, ResponsiveContainer, Tooltip, } from 'recharts';
import { ticks as getD3Ticks } from 'd3-array';
import { makeStyles } from '@material-ui/core';
import { ChartDot } from './ChartDot';
import calculateTooltipPosition from '../utils/calculate-tooltip-position';
import { getChartTicks, toRechartsHighlightFormat, orderData } from '../utils';
import { findTopDomain } from './utils';
import CHART_CONSTANTS, { chartMargins } from '../utils/constants';
import styles from './styles';
const { BOTTOM_DOMAIN, TICK_MARGIN, MIN_TICK_GAP, TICK_LINE, AXIS_LINE, IS_ANIMATION_ACTIVE, Y_AXIS_WIDTH, NUMBER_OF_TICKS, } = CHART_CONSTANTS;
const StyleOverrides = () => (React.createElement("style", { dangerouslySetInnerHTML: {
        __html: `
          .recharts-wrapper .recharts-cartesian-grid-horizontal line {
            stroke-dasharray: 3 3;
          }
          tspan {
            font-size: 11px;
            fill: ${palette.grey.dark};
          }
      `,
    } }));
const countNonReferenceLines = (lines) => Object.values(lines).filter(({ variant }) => !variant || variant === 'solid')
    .length;
const generateHighlightedAreas = (topDomain, dataPointCount, highlights) => {
    if (!highlights) {
        return null;
    }
    const highlightAreas = toRechartsHighlightFormat(topDomain, dataPointCount, highlights);
    return highlightAreas.map(highlightArea => highlightArea.map(props => (React.createElement(ReferenceArea, Object.assign({ key: Object.values(props).join('-') }, props)))));
};
const generateReferenceLines = (referenceLines) => {
    if (!referenceLines) {
        return null;
    }
    // eslint-disable-next-line id-length
    return referenceLines.map(({ y, color }) => (React.createElement(ReferenceLine, { key: `reference-line-${y}`, y: y, stroke: color, strokeDasharray: '3 3' })));
};
const generateLineGraphs = (lines, orderedData) => Object.keys(lines).map(name => {
    const line = lines[name];
    const isReferenceLine = line.variant === 'reference';
    return (React.createElement(Line, { key: `${line.color}-${name}`, data: orderedData, dataKey: name, stroke: line.color, dot: isReferenceLine ? false : React.createElement(ChartDot, { color: line.color }), isAnimationActive: IS_ANIMATION_ACTIVE, strokeDasharray: isReferenceLine ? '3 3' : 'none' }));
});
const positionOverride = { x: 0, y: 0 };
const useStyles = makeStyles(styles, {
    name: 'LineChart',
});
const defaultGetYAxisTicks = (domain) => getD3Ticks(domain[0], domain[1], NUMBER_OF_TICKS);
const TOOLTIP_WRAPPER_STYLE = { outline: 'none' };
export const LineChart = (props) => {
    const classes = useStyles();
    const { data, lineConfig: lines, unit, xAxisKey = 'x', height, tooltip, customTooltip, allowTooltipEscapeViewBox, highlights, referenceLines, showBottomYAxisLabel, children, getXAxisTicks = getChartTicks, getYAxisTicks = defaultGetYAxisTicks, formatYAxisTick, } = props;
    const yKey = Object.keys(lines)[0];
    const isSingleChart = countNonReferenceLines(lines) === 1;
    const topDomain = findTopDomain(data, xAxisKey);
    const orderedData = orderData(data);
    const xAxisTicks = getXAxisTicks(orderedData);
    const referenceLineList = generateReferenceLines(referenceLines);
    const highlightedAreas = generateHighlightedAreas(topDomain, orderedData.length - 1, highlights);
    const lineGraphs = generateLineGraphs(lines, orderedData);
    const formatTicks = (tick) => { var _a; return (_a = orderedData.find(item => item.order === tick)) === null || _a === void 0 ? void 0 : _a[xAxisKey]; };
    const containerRef = useRef(null);
    const tooltipRef = useRef(null);
    const getTooltipElement = () => (tooltipRef === null || tooltipRef === void 0 ? void 0 : tooltipRef.current) || null;
    const getChartElement = () => (containerRef === null || containerRef === void 0 ? void 0 : containerRef.current) || null;
    const onMouseMovement = (next) => {
        if (allowTooltipEscapeViewBox && (next === null || next === void 0 ? void 0 : next.isTooltipActive)) {
            const tooltipElem = getTooltipElement();
            const chartElem = getChartElement();
            calculateTooltipPosition(next, tooltipElem, chartElem);
        }
    };
    const yDomain = [BOTTOM_DOMAIN, topDomain];
    return (React.createElement("div", { 
        // ResponsiveContainer expects a wrapper with a fixed height
        style: { height }, ref: containerRef },
        React.createElement(StyleOverrides, null),
        React.createElement(ResponsiveContainer, null,
            React.createElement(ComposedChart, { margin: chartMargins, data: orderedData, onMouseMove: onMouseMovement, className: cx({
                    [classes.hideBottomYAxisLabel]: !showBottomYAxisLabel,
                }), overflow: 'visible' },
                React.createElement(CartesianGrid, { stroke: palette.grey.lighter2 }),
                React.createElement(XAxis, { type: 'number', dataKey: 'order', name: xAxisKey, tickLine: TICK_LINE, axisLine: AXIS_LINE, interval: 'preserveStartEnd', ticks: xAxisTicks, minTickGap: MIN_TICK_GAP, tickMargin: TICK_MARGIN, tickFormatter: formatTicks, domain: [BOTTOM_DOMAIN, orderedData.length - 1] }),
                React.createElement(YAxis, { type: 'number', dataKey: yKey, 
                    // re-charts will append unit even if we have a format function, hence it's removed here
                    unit: formatYAxisTick ? undefined : unit, domain: yDomain, tickLine: TICK_LINE, axisLine: AXIS_LINE, interval: 0, ticks: getYAxisTicks(yDomain), minTickGap: MIN_TICK_GAP, tickMargin: TICK_MARGIN, width: Y_AXIS_WIDTH, tickFormatter: formatYAxisTick
                        ? value => formatYAxisTick(value, yDomain)
                        : undefined }),
                referenceLineList,
                isSingleChart && (React.createElement(Area, { type: 'linear', dataKey: yKey, fill: palette.blue.main, fillOpacity: 0.1, isAnimationActive: IS_ANIMATION_ACTIVE })),
                lineGraphs,
                children,
                tooltip && (React.createElement(Tooltip, { wrapperStyle: TOOLTIP_WRAPPER_STYLE, allowEscapeViewBox: allowTooltipEscapeViewBox ? { x: true, y: true } : undefined, 
                    // override calculations for tooltip positioning
                    position: allowTooltipEscapeViewBox ? positionOverride : undefined, content: customTooltip, ref: (node) => (tooltipRef.current = (node === null || node === void 0 ? void 0 : node.wrapperNode) || null) })),
                highlightedAreas))));
};
LineChart.defaultProps = {
    height: 200,
    unit: 'd',
    tooltip: false,
    allowTooltipEscapeViewBox: false,
    xAxisKey: 'x',
};
LineChart.displayName = 'LineChart';
export default LineChart;
//# sourceMappingURL=LineChart.js.map