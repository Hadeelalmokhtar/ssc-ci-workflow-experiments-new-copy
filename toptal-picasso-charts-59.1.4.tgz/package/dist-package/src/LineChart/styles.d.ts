declare const _default: () => import("@material-ui/styles").StyleRules<{}, "hideBottomYAxisLabel">;
export default _default;
//# sourceMappingURL=styles.d.ts.map