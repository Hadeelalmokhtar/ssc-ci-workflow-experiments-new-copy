export { default as findTopDomain } from './find-top-domain';
//# sourceMappingURL=index.js.map