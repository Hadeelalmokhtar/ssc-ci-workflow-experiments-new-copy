import type { ChartDataPoint } from '../../../types';
declare const findTopDomain: (chartData: ChartDataPoint[], xAxisKey: string) => number;
export default findTopDomain;
//# sourceMappingURL=find-top-domain.d.ts.map