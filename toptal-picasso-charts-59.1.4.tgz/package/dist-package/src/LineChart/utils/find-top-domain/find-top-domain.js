var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import CHART_CONSTANTS from '../../../utils/constants';
const { BOTTOM_DOMAIN, TOP_DOMAIN_OFFSET } = CHART_CONSTANTS;
const findTopDomain = (chartData, xAxisKey) => Math.round(
// eslint-disable-next-line @typescript-eslint/no-unused-vars
chartData.reduce((acc, _a) => {
    var _b = xAxisKey, _ = _a[_b], yValues = __rest(_a, [typeof _b === "symbol" ? _b : _b + ""]);
    const maxY = Math.max(...Object.values(yValues));
    return maxY >= acc ? maxY : acc;
}, BOTTOM_DOMAIN) + TOP_DOMAIN_OFFSET);
export default findTopDomain;
//# sourceMappingURL=find-top-domain.js.map