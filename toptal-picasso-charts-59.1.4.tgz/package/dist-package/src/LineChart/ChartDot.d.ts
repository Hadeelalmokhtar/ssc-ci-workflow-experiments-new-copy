/// <reference types="react" />
import type { ChartDataPoint } from '../types';
export declare const ChartDot: ({ cx, cy, dataKey, color, payload, }: {
    cx?: number | undefined;
    dataKey?: string | undefined;
    payload?: ChartDataPoint | undefined;
    cy?: number | undefined;
    value?: string | number | null | undefined;
    color: string;
}) => JSX.Element;
//# sourceMappingURL=ChartDot.d.ts.map