import React from 'react';
export const ChartDot = ({ cx, cy, dataKey, color, payload, }) => {
    const isEmptyValue = payload && payload[`${dataKey}IsEmpty`];
    return (React.createElement("circle", { r: 3, cx: cx, cy: cy, strokeWidth: 1, stroke: color, strokeDasharray: 'none', fill: isEmptyValue ? 'white' : color }));
};
//# sourceMappingURL=ChartDot.js.map