/// <reference types="react" />
import type { BaseLineChartProps, ChartDataPoint, HighlightConfig } from '../types';
export declare type ReferenceLineType = {
    y: number;
    color: string;
};
export declare type Props = BaseLineChartProps & {
    /**
     * A list of data points to be rendered as a line chart
     * @type { [key: string]: string|number; }[]
     */
    data: ChartDataPoint[];
    /**
     * A list of regions to be highlighted
     * @type { from: number; to: number; color: string; }[]
     */
    highlights?: HighlightConfig[] | null;
    /**
     * Will display a full-width horizontal dashed line at the specified height in the specified color
     * @type { y: number; color: string; }[]
     */
    referenceLines?: ReferenceLineType[];
};
export declare const LineChart: {
    (props: Props): JSX.Element;
    defaultProps: {
        height: number;
        unit: string;
        tooltip: boolean;
        allowTooltipEscapeViewBox: boolean;
        xAxisKey: string;
    };
    displayName: string;
};
export default LineChart;
//# sourceMappingURL=LineChart.d.ts.map