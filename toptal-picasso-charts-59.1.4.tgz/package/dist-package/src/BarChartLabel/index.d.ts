import type { OmitInternalProps } from '@toptal/picasso-shared';
import type { Props } from './BarChartLabel';
export { default } from './BarChartLabel';
export declare type BarChartLabelProps = OmitInternalProps<Props>;
//# sourceMappingURL=index.d.ts.map