export { default } from './BarChartLabel';
//# sourceMappingURL=index.js.map