/// <reference types="react" />
import type { LabelProps } from 'recharts';
import type { BarOptions } from '../types';
export declare type Props = {
    value?: LabelProps['value'];
    viewBox?: {
        width?: number;
        x?: number;
        y?: number;
    };
    getBarLabelColor?: (params: BarOptions) => string;
    dataKey: string;
    index?: number;
};
declare const BarChartLabel: ({ value, viewBox, getBarLabelColor, ...restProps }: Props) => JSX.Element;
export default BarChartLabel;
//# sourceMappingURL=BarChartLabel.d.ts.map