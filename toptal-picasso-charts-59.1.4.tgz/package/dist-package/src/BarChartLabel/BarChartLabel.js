var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React from 'react';
const BarChartLabel = (_a) => {
    var _b, _c, _d;
    var { value, viewBox, getBarLabelColor } = _a, restProps = __rest(_a, ["value", "viewBox", "getBarLabelColor"]);
    const width = (_b = viewBox === null || viewBox === void 0 ? void 0 : viewBox.width) !== null && _b !== void 0 ? _b : 0;
    const xPosition = (_c = viewBox === null || viewBox === void 0 ? void 0 : viewBox.x) !== null && _c !== void 0 ? _c : 0;
    const yPosition = (_d = viewBox === null || viewBox === void 0 ? void 0 : viewBox.y) !== null && _d !== void 0 ? _d : 0;
    const fillColor = getBarLabelColor === null || getBarLabelColor === void 0 ? void 0 : getBarLabelColor(restProps);
    return (React.createElement("text", { x: xPosition + width / 2, y: yPosition, fill: fillColor, style: { fontSize: 11 }, textAnchor: 'middle', dy: -6 }, value));
};
export default BarChartLabel;
//# sourceMappingURL=BarChartLabel.js.map