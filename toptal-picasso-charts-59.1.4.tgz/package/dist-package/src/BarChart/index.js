export { default } from './BarChart';
//# sourceMappingURL=index.js.map