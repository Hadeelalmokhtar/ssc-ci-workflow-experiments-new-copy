var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React, { useMemo } from 'react';
import { palette } from '@toptal/picasso-utils';
import { BarChart as RechartsBarChart, CartesianGrid, XAxis, Tooltip, Bar, Customized, YAxis, ResponsiveContainer, Cell, } from 'recharts';
import { ticks as getD3Ticks } from 'd3-array';
import BarChartLabel from '../BarChartLabel';
import { BarChartIndicators } from '../BarChartIndicators';
import { defineStackId, findTopDomain } from './utils';
import CHART_CONSTANTS, { chartMargins } from '../utils/constants';
const { TICK_MARGIN, MIN_TICK_GAP, TICK_LINE, AXIS_LINE, Y_AXIS_WIDTH, BOTTOM_DOMAIN, NUMBER_OF_TICKS, TICK_WIDTH, TICK_HEIGHT, } = CHART_CONSTANTS;
const TOOLTIP_WRAPPER_STYLE = { outline: 'none' };
const StyleOverrides = () => (React.createElement("style", { dangerouslySetInnerHTML: {
        __html: `
          tspan {
            font-size: 11px;
            fill: ${palette.grey.dark};
          }
      `,
    } }));
export const formatData = (data) => data.map(dataItem => (Object.assign(Object.assign({}, dataItem.value), dataItem)));
const defaultGetBarColor = () => palette.blue.main;
const defaultGetBarLabelColor = () => palette.grey.dark;
export const extractValues = (data) => data.map(dataItem => dataItem.value);
const DEFAULT_BAR_CATEGORY_GAP = 50;
const DEFAULT_BAR_SIZE = 32;
const DEFAULT_BAR_GAP = 2;
const BarChart = (_a) => {
    var { data, className, height, width, tooltip, customTooltip, allowTooltipEscapeViewBox, getBarColor = defaultGetBarColor, labelKey = 'name', getBarLabelColor = defaultGetBarLabelColor, renderBarIndicators, testIds, showBarLabel, isAnimationActive, layout, stackedBars, showEveryNthTickOnXAxis = 1, showEveryNthTickOnYAxis = 1, autoSize, maxBarSize, valueAxisTickFormatter } = _a, rest = __rest(_a, ["data", "className", "height", "width", "tooltip", "customTooltip", "allowTooltipEscapeViewBox", "getBarColor", "labelKey", "getBarLabelColor", "renderBarIndicators", "testIds", "showBarLabel", "isAnimationActive", "layout", "stackedBars", "showEveryNthTickOnXAxis", "showEveryNthTickOnYAxis", "autoSize", "maxBarSize", "valueAxisTickFormatter"]);
    const horizontal = layout === 'horizontal';
    const dataKeys = Object.keys(data[0].value);
    const formattedData = formatData(data);
    const tooltipElement = useMemo(() => tooltip ? (React.createElement(Tooltip, { wrapperStyle: TOOLTIP_WRAPPER_STYLE, "data-testid": testIds === null || testIds === void 0 ? void 0 : testIds.tooltip, allowEscapeViewBox: allowTooltipEscapeViewBox ? { x: true, y: true } : undefined, content: customTooltip, cursor: false })) : undefined, [tooltip, customTooltip, allowTooltipEscapeViewBox, testIds === null || testIds === void 0 ? void 0 : testIds.tooltip]);
    const topDomain = findTopDomain(extractValues(data), stackedBars);
    const ticks = getD3Ticks(BOTTOM_DOMAIN, topDomain, NUMBER_OF_TICKS);
    const categoryAxisProps = {
        dataKey: labelKey,
        height: TICK_HEIGHT,
        interval: 0,
        tick: { width: TICK_WIDTH },
    };
    const valueAxisProps = {
        width: Y_AXIS_WIDTH,
        ticks: ticks,
        domain: [ticks[0], ticks[ticks.length - 1]],
        tickFormatter: valueAxisTickFormatter,
    };
    const xAxisProps = horizontal ? categoryAxisProps : valueAxisProps;
    const yAxisProps = !horizontal ? categoryAxisProps : valueAxisProps;
    // If ticks are not shown, the corresponding axis is not rendered to avoid empty space
    const renderXAxis = showEveryNthTickOnXAxis !== 0;
    const renderYAxis = showEveryNthTickOnYAxis !== 0;
    return (React.createElement("div", Object.assign({ style: { height, width }, className: className }, rest),
        React.createElement(StyleOverrides, null),
        React.createElement(ResponsiveContainer, { width: width, height: height },
            React.createElement(RechartsBarChart, { layout: layout, margin: chartMargins, data: formattedData, maxBarSize: maxBarSize, barGap: DEFAULT_BAR_GAP, barCategoryGap: !autoSize ? DEFAULT_BAR_CATEGORY_GAP : undefined, barSize: !autoSize ? DEFAULT_BAR_SIZE : undefined, overflow: 'visible' },
                React.createElement(CartesianGrid, { strokeDasharray: '3 3', stroke: palette.grey.lighter2, vertical: !horizontal }),
                renderXAxis && (React.createElement(XAxis, Object.assign({}, xAxisProps, { type: horizontal ? 'category' : 'number', tickLine: TICK_LINE, axisLine: AXIS_LINE, minTickGap: MIN_TICK_GAP, tickMargin: TICK_MARGIN, interval: showEveryNthTickOnXAxis - 1 }))),
                renderYAxis && (React.createElement(YAxis, Object.assign({}, yAxisProps, { type: horizontal ? 'number' : 'category', tickLine: TICK_LINE, axisLine: AXIS_LINE, minTickGap: MIN_TICK_GAP, tickMargin: TICK_MARGIN, interval: showEveryNthTickOnYAxis - 1 }))),
                tooltipElement,
                dataKeys.map(dataKey => (React.createElement(Bar, { key: dataKey, dataKey: dataKey, label: showBarLabel ? (React.createElement(BarChartLabel, { dataKey: dataKey, getBarLabelColor: getBarLabelColor })) : undefined, isAnimationActive: isAnimationActive, stackId: stackedBars && defineStackId(dataKey, stackedBars) }, data.map((entry, index) => {
                    const fill = getBarColor === null || getBarColor === void 0 ? void 0 : getBarColor({ dataKey, entry, index });
                    return (React.createElement(Cell, { key: `${entry.value}-${entry.name}-${String(index)}`, fill: fill }));
                })))),
                renderBarIndicators && (React.createElement(Customized, { component: React.createElement(BarChartIndicators, { renderIndicator: renderBarIndicators }) }))))));
};
BarChart.defaultProps = {
    height: 200,
    width: 'auto',
    tooltip: false,
    showBarLabel: true,
    labelKey: 'name',
    layout: 'horizontal',
};
export default BarChart;
//# sourceMappingURL=BarChart.js.map