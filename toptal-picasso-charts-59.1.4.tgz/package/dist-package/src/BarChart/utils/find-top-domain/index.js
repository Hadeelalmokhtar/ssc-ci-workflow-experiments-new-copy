export { default } from './find-top-domain';
//# sourceMappingURL=index.js.map