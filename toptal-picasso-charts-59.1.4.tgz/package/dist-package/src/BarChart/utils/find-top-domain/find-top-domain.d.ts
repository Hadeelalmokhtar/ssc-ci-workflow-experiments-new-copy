declare type DataItem = {
    [key: string]: any;
};
/**
 * Determines the absolute maximum value of the data set (does not necessary match the highest value).
 * This is later used as the upper boundary of the range for which the ticks are calculated.
 */
declare const findTopDomain: (data: DataItem[], stackedBars?: string[][]) => number;
export default findTopDomain;
//# sourceMappingURL=find-top-domain.d.ts.map