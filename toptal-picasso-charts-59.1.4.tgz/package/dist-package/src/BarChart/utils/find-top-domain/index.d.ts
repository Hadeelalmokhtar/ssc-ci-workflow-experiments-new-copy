export { default } from './find-top-domain';
//# sourceMappingURL=index.d.ts.map