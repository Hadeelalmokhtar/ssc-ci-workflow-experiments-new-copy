declare const defineStackId: (dataKey: string, stackedBars: string[][]) => string | undefined;
export default defineStackId;
//# sourceMappingURL=define-stack-id.d.ts.map