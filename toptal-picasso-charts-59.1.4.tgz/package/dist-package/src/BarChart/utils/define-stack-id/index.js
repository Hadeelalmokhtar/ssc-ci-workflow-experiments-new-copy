export { default } from './define-stack-id';
//# sourceMappingURL=index.js.map