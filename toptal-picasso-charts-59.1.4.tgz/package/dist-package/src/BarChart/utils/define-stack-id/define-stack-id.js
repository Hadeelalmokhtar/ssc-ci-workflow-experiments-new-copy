const defineStackId = (dataKey, stackedBars) => {
    const stackIndex = stackedBars === null || stackedBars === void 0 ? void 0 : stackedBars.find(barsList => barsList.includes(dataKey));
    if (stackIndex) {
        return `stack${stackIndex}`;
    }
    return undefined;
};
export default defineStackId;
//# sourceMappingURL=define-stack-id.js.map