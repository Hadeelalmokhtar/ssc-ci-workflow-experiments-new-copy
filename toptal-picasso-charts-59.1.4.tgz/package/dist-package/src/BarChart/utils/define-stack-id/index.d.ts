export { default } from './define-stack-id';
//# sourceMappingURL=index.d.ts.map