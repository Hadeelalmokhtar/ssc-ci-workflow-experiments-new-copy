import type { ReactNode } from 'react';
import type { BaseChartProps, BarChartDataItem, BarOptions } from '../types';
declare type ShowEverytNthTickValue = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
export interface Props<K extends string | number | symbol> extends BaseChartProps {
    /**
     * A list of data points to be rendered as a bar chart
     * @type { name: string; value: { [key in K]: number }; }[]
     */
    data: BarChartDataItem<K>[];
    /** Name of point on the horizontal axis */
    labelKey?: string;
    /** Maps bar's key with a color to fill */
    getBarColor: (params: {
        dataKey: string;
        entry?: {
            name: string;
            value: {
                [key in K]: any;
            };
        };
        index?: number;
    }) => string;
    /** Maps bar's key with a label color */
    getBarLabelColor?: (params: BarOptions) => string;
    /** Customizes the bar indicators */
    renderBarIndicators?: (params: BarOptions) => ReactNode;
    testIds?: {
        tooltip?: string;
    };
    /** Shows label of each bar */
    showBarLabel?: boolean;
    /** If set false, animation of bar will be disabled */
    isAnimationActive?: boolean;
    /** List of bar groups to be stacked. i.e.: [ ['a', 'b'], ['c', 'd'] ] */
    stackedBars?: string[][];
    /** Makes X-axis show only every Nth tick. `0` hides all ticks, `1` shows all ticks (default behavior), `2` shows every 2nd tick, and so on */
    showEveryNthTickOnXAxis?: ShowEverytNthTickValue;
    /** Makes Y-axis show only every Nth tick. `0` hides all ticks, `1` shows all ticks (default behavior), `2` shows every 2nd tick, and so on */
    showEveryNthTickOnYAxis?: ShowEverytNthTickValue;
    /** If bars should fill all the empty space */
    autoSize?: boolean;
    /** Maximum size for the bar */
    maxBarSize?: number;
    /** Function to format ticks of the value axis */
    valueAxisTickFormatter?: ((value: any, index: number) => string) | undefined;
}
export declare const formatData: <T extends string>(data: BarChartDataItem<T>[]) => ({ [key in T]: string | number | symbol; } & BarChartDataItem<T>)[];
export declare const extractValues: <T extends string>(data: BarChartDataItem<T>[]) => { [key in T]: string | number | symbol; }[];
declare const BarChart: {
    <T extends string>({ data, className, height, width, tooltip, customTooltip, allowTooltipEscapeViewBox, getBarColor, labelKey, getBarLabelColor, renderBarIndicators, testIds, showBarLabel, isAnimationActive, layout, stackedBars, showEveryNthTickOnXAxis, showEveryNthTickOnYAxis, autoSize, maxBarSize, valueAxisTickFormatter, ...rest }: Props<T>): JSX.Element;
    defaultProps: {
        height: number;
        width: string;
        tooltip: boolean;
        showBarLabel: boolean;
        labelKey: string;
        layout: string;
    };
};
export default BarChart;
//# sourceMappingURL=BarChart.d.ts.map