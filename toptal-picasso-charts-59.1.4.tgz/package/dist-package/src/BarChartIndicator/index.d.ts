import type { OmitInternalProps } from '@toptal/picasso-shared';
import type { Props } from './BarChartIndicator';
export { default } from './BarChartIndicator';
export declare type BarChartIndicatorProps = OmitInternalProps<Props>;
//# sourceMappingURL=index.d.ts.map