export { default } from './BarChartIndicator';
//# sourceMappingURL=index.js.map