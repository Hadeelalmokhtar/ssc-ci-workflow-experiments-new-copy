import React from 'react';
import { Rectangle } from 'recharts';
const INDICATOR_SIZE = 16;
const BarChartIndicator = ({ color, label }) => (React.createElement(React.Fragment, null,
    React.createElement(Rectangle, { width: INDICATOR_SIZE, height: INDICATOR_SIZE, x: -INDICATOR_SIZE / 2, y: -INDICATOR_SIZE / 2, fill: color, radius: 2 }),
    React.createElement("text", { x: 0, y: 0, textAnchor: 'middle', alignmentBaseline: 'middle', fill: '#fff', style: { fontSize: 11, fontWeight: 600 } }, label)));
export default BarChartIndicator;
//# sourceMappingURL=BarChartIndicator.js.map