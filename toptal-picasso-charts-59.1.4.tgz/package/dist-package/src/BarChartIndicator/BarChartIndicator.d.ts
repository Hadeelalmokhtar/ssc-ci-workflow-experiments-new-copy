/// <reference types="react" />
export declare type Props = {
    color: string;
    label: string;
};
declare const BarChartIndicator: ({ color, label }: Props) => JSX.Element;
export default BarChartIndicator;
//# sourceMappingURL=BarChartIndicator.d.ts.map