import type { ReactNode } from 'react';
export declare type Props = {
    renderIndicator: (params: any) => ReactNode;
    formattedGraphicalItems?: any;
};
export declare const BarChartIndicators: ({ formattedGraphicalItems, renderIndicator, }: Props) => any;
//# sourceMappingURL=BarChartIndicators.d.ts.map