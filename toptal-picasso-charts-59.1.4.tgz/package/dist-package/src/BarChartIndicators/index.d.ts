import type { OmitInternalProps } from '@toptal/picasso-shared';
import type { Props } from './BarChartIndicators';
export { BarChartIndicators } from './BarChartIndicators';
export declare type BarChartIndicatorsProps = OmitInternalProps<Props>;
//# sourceMappingURL=index.d.ts.map