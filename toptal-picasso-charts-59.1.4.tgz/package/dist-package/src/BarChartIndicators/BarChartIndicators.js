import React from 'react';
const INDICATOR_SIZE = 16;
export const BarChartIndicators = ({ formattedGraphicalItems, renderIndicator, }) => {
    return formattedGraphicalItems.map((seriesData) => {
        var _a;
        const series = (_a = seriesData === null || seriesData === void 0 ? void 0 : seriesData.props) === null || _a === void 0 ? void 0 : _a.data;
        return series.map((item, index) => {
            const dataKey = item.name;
            const dataItem = item;
            const barIndicatorComponent = renderIndicator({
                dataKey,
                index,
                dataItem,
            });
            if (!barIndicatorComponent) {
                return;
            }
            return (React.createElement("svg", { key: `indicator-${dataKey}`, width: INDICATOR_SIZE, height: INDICATOR_SIZE, x: item.x + item.width / 2, y: item.y + item.height, overflow: 'visible' }, barIndicatorComponent));
        });
    });
};
//# sourceMappingURL=BarChartIndicators.js.map