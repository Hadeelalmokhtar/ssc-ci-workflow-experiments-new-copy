export { default } from './calculate-tooltip-position';
//# sourceMappingURL=index.d.ts.map