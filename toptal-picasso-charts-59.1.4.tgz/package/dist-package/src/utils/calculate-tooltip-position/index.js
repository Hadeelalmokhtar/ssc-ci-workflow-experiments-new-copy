export { default } from './calculate-tooltip-position';
//# sourceMappingURL=index.js.map