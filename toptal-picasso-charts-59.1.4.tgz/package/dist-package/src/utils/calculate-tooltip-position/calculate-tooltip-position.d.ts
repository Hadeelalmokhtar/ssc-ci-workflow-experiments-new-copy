import type { CoordinatePayload, PositionTranslate } from '../../types';
export declare const getTooltipTranslate: ({ key, cursorCoordinate, chartScreenOffset, tooltipDimension, screenDimension, offset, viewbox, }: PositionTranslate) => number;
export declare const calculateTooltipPosition: ((payload: CoordinatePayload, tooltipElem: HTMLDivElement | null, chartElem: HTMLDivElement | null) => void) & {
    clear(): void;
};
export default calculateTooltipPosition;
//# sourceMappingURL=calculate-tooltip-position.d.ts.map