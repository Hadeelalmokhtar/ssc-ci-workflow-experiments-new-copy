import type { OrderedChartDataPoint } from '../../types';
declare const getChartTicks: (orderedData: OrderedChartDataPoint[]) => number[];
export default getChartTicks;
//# sourceMappingURL=get-chart-ticks.d.ts.map