export { default } from './get-chart-ticks';
//# sourceMappingURL=index.d.ts.map