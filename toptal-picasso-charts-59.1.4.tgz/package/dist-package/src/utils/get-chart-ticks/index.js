export { default } from './get-chart-ticks';
//# sourceMappingURL=index.js.map