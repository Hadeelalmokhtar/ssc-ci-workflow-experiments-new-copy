const getChartTicks = (orderedData) => orderedData.map(({ order }) => order);
export default getChartTicks;
//# sourceMappingURL=get-chart-ticks.js.map