declare const chartConstants: {
    BOTTOM_DOMAIN: number;
    HIGHLIGHT_BOTTOM_START_POINT: number;
    HIGHLIGHT_BOTTOM_FILL_OPACITY: number;
    HIGHLIGHT_TOP_FILL_OPACITY: number;
    HIGHLIGHT_TOP_HEIGHT_RATIO: number;
    TOP_DOMAIN_OFFSET: number;
    TICK_MARGIN: number;
    TICK_WIDTH: number;
    TICK_HEIGHT: number;
    MIN_TICK_GAP: number;
    DEFAULT_MARGIN: number;
    TICK_LINE: boolean;
    AXIS_LINE: boolean;
    IS_ANIMATION_ACTIVE: boolean;
    Y_AXIS_WIDTH: number;
    TOOLTIP_OFFSET: number;
    SCROLL_BAR_WIDTH: number;
    NUMBER_OF_TICKS: number;
};
export declare const chartMargins: {
    top: number;
    right: number;
    bottom: number;
    left: number;
};
export default chartConstants;
//# sourceMappingURL=constants.d.ts.map