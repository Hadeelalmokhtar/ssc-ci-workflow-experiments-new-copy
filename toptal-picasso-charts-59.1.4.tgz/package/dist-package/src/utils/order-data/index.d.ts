export { default } from './order-data';
//# sourceMappingURL=index.d.ts.map