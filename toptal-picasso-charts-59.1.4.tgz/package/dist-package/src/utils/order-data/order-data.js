const orderData = (data) => data.map((point, index) => (Object.assign(Object.assign({}, point), { order: index })));
export default orderData;
//# sourceMappingURL=order-data.js.map