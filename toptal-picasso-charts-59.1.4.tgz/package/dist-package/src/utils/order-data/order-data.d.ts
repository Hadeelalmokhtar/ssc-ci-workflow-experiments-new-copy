import type { OrderedChartDataPoint, ChartDataPoint } from '../../types';
declare const orderData: (data: ChartDataPoint[]) => OrderedChartDataPoint[];
export default orderData;
//# sourceMappingURL=order-data.d.ts.map