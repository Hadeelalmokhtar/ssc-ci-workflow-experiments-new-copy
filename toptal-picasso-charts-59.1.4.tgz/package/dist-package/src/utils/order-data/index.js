export { default } from './order-data';
//# sourceMappingURL=index.js.map