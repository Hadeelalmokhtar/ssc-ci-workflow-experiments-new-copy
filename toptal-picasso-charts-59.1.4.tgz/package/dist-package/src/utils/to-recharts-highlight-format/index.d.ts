export { default } from './to-recharts-highlight-format';
//# sourceMappingURL=index.d.ts.map