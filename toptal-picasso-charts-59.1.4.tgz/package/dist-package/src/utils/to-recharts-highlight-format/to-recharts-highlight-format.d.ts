import type { HighlightConfig } from '../../types';
declare const toRechartsHighlightFormat: (topDomain: number, dataPointCount: number, data: HighlightConfig[]) => {
    x1: number;
    x2: number;
    y1: number;
    y2: number;
    fillOpacity: number;
    fill: string;
}[][];
export default toRechartsHighlightFormat;
//# sourceMappingURL=to-recharts-highlight-format.d.ts.map