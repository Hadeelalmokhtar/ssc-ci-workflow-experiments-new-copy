export { default } from './to-recharts-highlight-format';
//# sourceMappingURL=index.js.map