from setuptools import setup
setup(
    name="data-exfil-pkg",
    version="1.0.0",
    packages=["data_exfil_pkg"],
)
